//Oswald by Mojo
//Setting up time function

function timefunc() {
        var dt = new Date();    // DATE() VAR FOR CURRENT SYSTEM DATE AND TIME.
        var hrs = dt.getHours();
        var min = dt.getMinutes();
        var sec = dt.getSeconds();
        
        
        min = Ticking(min);
        sec = Ticking(sec);

        
        if(hrs == 0){
          hrs = 12;
        }else {
          hrs = hrs;
        }
        
        if(hrs > 12){
          hrs = hrs - 12;
        }

        if(hrs < 10){
          hrs = "0" + hrs;
        }
        document.getElementById('time').innerHTML = hrs + ":" + min;

        // CALL THE FUNCTION EVERY 1 SECOND (RECURSION).
        var time
        time = setInterval('timefunc()', 1000);

        /*if (hrs > 12){
          document.getElementById('ampm').innerHTML = "Good Afternoon";
        }else if(hrs < 12){
          document.getElementById('ampm').innerHTML = "Good Morning";
        }*/

        var today = new Date();
      //An array that lets us assign the numbers to a real month
      
      var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

      var dt = today.getDate();
      var y = today.getFullYear();

      //Setting Element
      document.getElementById('date').innerHTML = months[today.getMonth()] + " " + dt + "," + " " + y;
      
    }

    function Ticking(ticVal) {
        if (ticVal < 10) {
            ticVal = "0" + ticVal;
        }
        return ticVal;
    }