return {
    {
        name = "preamp",
        gain = -4.1659150123596,
    },
    {
        name = "lowshelf",
        frequency = 31,
        Q = 1,
        gain = 2.558456,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = 2.405803,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 1,
        gain = 2.826363,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 3.4838709677419,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = 3.885402,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = -2.049911,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = 2.663949,
    },
    {
        name = "highshelf",
        frequency = 6000,
        Q = 0.259904,
        gain = 4.20269,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = -1.502439,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 2,
        gain = -2.326669,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 2,
        gain = -3.817947,
    },
}