//PrettyInP1nk by Mojo
//Funtion is called on load ofg widget
    function digitized() {
        var dt = new Date();    //Declaring Date/Time
        var hrs = dt.getHours();
        var min = dt.getMinutes();
        var sec = dt.getSeconds();
        
        
        /* min = Ticking(min);
        sec = Ticking(sec); */

        var minarray = ["o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen" , "eighteen", "nineteen" , "twenty" , "twenty-one", "twenty-two", "twenty-three", "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight", "twenty-nine", "thirty", "thirty-one", "thirty-two", "thirty-three", "thirty-four", "thirty-five", "thirty-six", "thirty-seven", "thirty-eight", "thirty-nine", "fourty", "fourty-one", "fourty-two", "fourty-three", "fourty-four", "fourty-five", "fourty-six", "fourty-seven", "fourty-eight", "fourty-nine", "fifty", "fifty-one", "fifty-two", "fifty-three", "fifty-four", "fifty-five", "fifty-six", "fifty-seven", "fifty-eight", "fifty-nine"];

        var hrarray = ["twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve"]

        if (hrs > 12){
          hrs = hrs - 12;
          //console.log(hrs);
        }

        document.getElementById('hour').innerHTML = hrarray[hrs];

        document.getElementById('minute').innerHTML = minarray[min];

        //Repeats funtion and checks time every second
        var time;
        time = setInterval('digitized()', 1000);

         

      /* var today = new Date();
      //An array that lets us assign the numbers to a real month
      
      var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

      var dt = today.getDate();
      var y = today.getFullYear();

      //Setting Element
      document.getElementById('date').innerHTML = "Today is " + months[today.getMonth()] + " " + dt + "," + " " + y; */
    
    }

    /*function Ticking(ticVal) {
        if (ticVal < 10) {
            ticVal = "0" + ticVal;
        }
        return ticVal; 

    } */
    //Thanks to Encodedna for the time code @https://www.encodedna.com/2012/11/javascript-digital-clock.htm