//Oswald By Mojo
function mainUpdate(type){
    if(type == "weather"){
        if(weather.conditionCode = 0){
        document.getElementById("weathericon").src = "icons/256/4894512 - air blow direction nature weather wind windy.png";
        //tornado
        }else if(weather.conditionCode = 1){
          document.getElementById("weathericon").src = "";
          //tropical storms
        }else if(weather.conditionCode = 2){
          document.getElementById("weathericon").src = "";
          //hurricane
        }else if(weather.conditionCode = 3){
          document.getElementById("weathericon").src = "";
          //severe thunderstorms
        }else if(weather.conditionCode = 4){
          document.getElementById("weathericon").src = "";
          //thunderstorms
        }else if(weather.conditionCode = 5){
          document.getElementById("weathericon").src = "";
          //mixed rain and snow
        }else if(weather.conditionCode = 6){
          document.getElementById("weathericon").src = "";
          //mixed rain and sleet
        }else if(weather.conditionCode = 7){
          document.getElementById("weathericon").src = "";
          //mixed snow and sleet
        }else if(weather.conditionCode = 8){
          document.getElementById("weathericon").src = "";
          //freezing drizzle  
        }else if(weather.conditionCode = 9){
          document.getElementById("weathericon").src = "icons/256/4894511 - drops forecast rain rainy umbrella water weather.png";
          //drizzle
        }else if(weather.conditionCode = 10){
          document.getElementById("weathericon").src = "";
          //freezing rain 
        }else if(weather.conditionCode = 11){
          document.getElementById("weathericon").src = "icons/256/4894521 - cloud drop forecast rain rainy water weather.png";
          //showers
        }else if(weather.conditionCode = 12){
          document.getElementById("weathericon").src = "icons/256/4894521 - cloud drop forecast rain rainy water weather.png";
          //rain
        }else if(weather.conditionCode = 13){
          document.getElementById("weathericon").src = "";
          //snow flurries
        }else if(weather.conditionCode = 14){
          document.getElementById("weathericon").src = "";
          //light snow showers
        }else if(weather.conditionCode = 15){
          document.getElementById("weathericon").src = "";
          //blowing snow
        }else if(weather.conditionCode = 16){
          document.getElementById("weathericon").src = "";
          //snow
        }else if(weather.conditionCode = 17){
          document.getElementById("weathericon").src = "";
          //hail
        }else if(weather.conditionCode = 18){
          document.getElementById("weathericon").src = "";
          //sleet
        }else if(weather.conditionCode = 19){
          document.getElementById("weathericon").src = "";
          //dust
        }else if(weather.conditionCode = 20){
          document.getElementById("weathericon").src = "";
          //foggy
        }else if(weather.conditionCode = 21){
          document.getElementById("weathericon").src = "";
          //haze
        }else if(weather.conditionCode = 22){
          document.getElementById("weathericon").src = "";
          //smoky
        }else if(weather.conditionCode = 23){
          document.getElementById("weathericon").src = "";
          //blustery
        }else if(weather.conditionCode = 24){
          document.getElementById("weathericon").src = "icons/256/4894512 - air blow direction nature weather wind windy.png";
          //windy
        }else if(weather.conditionCode = 25){
          document.getElementById("weathericon").src = "";
          //cold
        }else if(weather.conditionCode = 26){
          document.getElementById("weathericon").src = "";
          //cloudy
        }else if(weather.conditionCode = 27){
          document.getElementById("weathericon").src = "icons/256/4894519 - cloud crescent half moon night sleep weather.png";
          //night mostly cloudy
        }else if(weather.conditionCode = 28){
          document.getElementById("weathericon").src = "icons/256/4894525 - cloud day shine summer sun sunny weather.png";
          //day mostly cloudy
        }else if(weather.conditionCode = 29){
          document.getElementById("weathericon").src = "icons/256/4894519 - cloud crescent half moon night sleep weather.png";
          //night partly cloudy
        }else if(weather.conditionCode = 30){
          document.getElementById("weathericon").src = "icons/256/4894525 - cloud day shine summer sun sunny weather.png";
          //partly cloudy day
        }else if(weather.conditionCode = 31){
          document.getElementById("weathericon").src = "icons/256/4894532 - crescent half moon nature night sleep weather.png";
          //clear night
        }else if(weather.conditionCode = 32){
          document.getElementById("weathericon").src = "icons/256/4894508 - forecast shine summer sun sunny warm weather.png";
          //clear day/sunny
        }else if(weather.conditionCode = 33){
          document.getElementById("weathericon").src = "icons/256/4894510 - clean galaxy light night shinny stars weather.png";
          //fair night
        }else if(weather.conditionCode = 34){
          document.getElementById("weathericon").src = "";
          //fair day
        }else if(weather.conditionCode = 35){
          document.getElementById("weathericon").src = "";
          //mixed rain + hail
        }else if(weather.conditionCode = 36){
          document.getElementById("weathericon").src = "";
          //hot
        }else if(weather.conditionCode = 37){
          document.getElementById("weathericon").src = "";
          //isolated thunderstorms
        }else if(weather.conditionCode = 38){
          document.getElementById("weathericon").src = "";
          //scattered thunderstorms
        }else if(weather.conditionCode = 39){
          document.getElementById("weathericon").src = "icons/256/4894524 - cloud rain rainy sun sunny water weather.png";
          //day scattered showers
        }else if(weather.conditionCode = 40){
          document.getElementById("weathericon").src = "icons/256/4894530 - drop drops rain rainy water weather wet.png";
          //heavy rain
        }else if(weather.conditionCode = 41){
          document.getElementById("weathericon").src = "";
          //day scattered snow
        }else if(weather.conditionCode = 42){
          document.getElementById("weathericon").src = "";
          //heavy snow
        }else if(weather.conditionCode = 43){
          document.getElementById("weathericon").src = "";
          //blizzard
        }else if(weather.conditionCode = 44){
          document.getElementById("weathericon").src = "icons/256/4894513 - close cloud data interface remove user weather.png";
          //not availabe
        }else if(weather.conditionCode = 45){
          document.getElementById("weathericon").src = "icons/256/4894520 - cloud drop moon rain rainy water weather.png";
          //scattered showers night
        }else if(weather.conditionCode = 46){
          document.getElementById("weathericon").src = "";
          //scattered snow showers night
        }else if(weather.conditionCode = 47){
          document.getElementById("weathericon").src = "";
          //scattred thundershowers
        } 

        
    }
}