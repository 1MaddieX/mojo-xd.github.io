return {
    {
        name = "preamp",
        gain = -7.3029689788818,
    },
    {
        name = "eq",
        frequency = 31,
        Q = 1,
        gain = 0.343429,
    },
    {
        name = "eq",
        frequency = 60,
        Q = 1,
        gain = 0.682252,
    },
    {
        name = "eq",
        frequency = 170,
        Q = 1,
        gain = -0.336901,
    },
    {
        name = "eq",
        frequency = 310,
        Q = 1,
        gain = 1.102166,
    },
    {
        name = "eq",
        frequency = 600,
        Q = 1,
        gain = 3.4838709677419,
    },
    {
        name = "eq",
        frequency = 1000,
        Q = 1,
        gain = 0.7741935483871,
    },
    {
        name = "eq",
        frequency = 3000,
        Q = 1,
        gain = -3.0967741935484,
    },
    {
        name = "eq",
        frequency = 6000,
        Q = 1,
        gain = -5.8064516129032,
    },
    {
        name = "eq",
        frequency = 12000,
        Q = 2,
        gain = -6.9677419354839,
    },
    {
        name = "eq",
        frequency = 14000,
        Q = 2,
        gain = -7.3548387096774,
    },
    {
        name = "eq",
        frequency = 16000,
        Q = 2,
        gain = -7.3548387096774,
    },
}