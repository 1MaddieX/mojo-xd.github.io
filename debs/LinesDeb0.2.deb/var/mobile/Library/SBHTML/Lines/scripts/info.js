//Lines by Mojo

//Defining XenINFO elements and applying XenINFO to elements

function mainUpdate(type){
    if(type == "weather"){
    //weather elements.
    document.getElementById("weather").innerHTML = "It's " + weather.temperature + "&deg; " + "outside";
    document.getElementById("highlow").innerHTML = "Today, it'll be a high of " + weather.high + "&deg; and a low of " + weather.low + "&deg;";
    }else if (type == "battery"){
    //battery elements
    document.getElementById("battstat").innerHTML = "Your phone is at " + batteryPercent + "%";
      if (batteryCharging == true){
        document.getElementById("charging").innerHTML = "Your phone is plugged in";}
      else {
        document.getElementById("charging").innerHTML = "Your phone is away from it's charger";}
    }else if (type == "events"){ //event element
        document.getElementById("events").innerHTML = "Upcoming: " + events[0].title;
      }

}
